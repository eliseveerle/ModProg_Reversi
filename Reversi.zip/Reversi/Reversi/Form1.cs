﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Reversi
{
    public partial class Form1 : Form
    {
        bool einde_spel;
        bool zet_niet_mogelijk;
        int hor;
        int vert;
        int[,] vak;
        int breedte;
        int beurt;
        int aantal;
        int richtingx;
        int richtingy;
        bool help;
        List <Array> standoud;
        int aantalzetten;
        public Form1()
        {
            InitializeComponent();
            startspel();
            Panel.Paint += this.tekenveld;
            Panel.MouseClick += this.zetwaardes;
            this.ClientSizeChanged += this.vergroten;

        }
        // de beginwaardes van het spel worden hier vastgezet
        void startspel ()
        { 
            zet_niet_mogelijk = false;
            einde_spel = false;
            help = false;
            beurt = 1;
            this.hor = int.Parse(textBox_x.Text);
            this.vert = int.Parse(textBox_y.Text);
            vak = new int[hor, vert];
            standoud = new List<Array> ();
            aantalzetten = 0;
            this.aantal = 0;
            this.richtingx = 0;
            this.richtingy = 0;
            label1.Text = "rood begint";
            zetbreedte();
            zetarray();
        }

        // alle onderdelen van de array krijgen hier een beginwaarde
        void zetarray ()
        {
            int handig_v = (vert / 2) - 1;
            int handig_h = (hor / 2) - 1;
            for (int i = 0; i < hor; i++)
            {

                for (int j = 0; j < vert; j++)
                {
                    if ((i == handig_h && j == handig_v) || (i == (handig_h + 1) && j == (handig_v + 1)))
                    {
                        vak[i, j] = 2;
                    }
                    else if ((i == handig_h && j == (handig_v + 1)) || (i == (handig_h + 1) && j == handig_v))
                    {
                        vak[i, j] = 1;
                    }
                    else
                    {
                        vak[i, j] = 0;
                    }
                }
            }
            label_rood.Text = "2 stenen";
            label_blauw.Text = "2 stenen";
        }

        // op basis van het aantal gevraagde hokjes in elke richting en het formaat van het window wordt hier de breedte van individuele hokjes bepaald
        void zetbreedte ()
        {
            int h = (Panel.Size.Height - 1) / vert;
            int b = (Panel.Size.Width - 1) / hor;
            if (b > h)
                breedte = h ;
            else
                breedte = b ;
        }

        //panel mee laten schalen met het window
        void vergroten (object o, EventArgs ea)
           {
               int w = this.ClientSize.Width - 30;
               int h = this.ClientSize.Height - 110;
               Panel.Size = new Size(w, h);
               zetbreedte();
               Panel.Invalidate();
           }
        //hersteld naar begin waardes als reset button wordt ingedrukt
        private void Reset_Click(object sender, EventArgs e)
        {
            zetarray();
            Panel.Invalidate();
        }
        // geeft bool help de tegenovergestelde waarde zodat de hulp rondjes geactiveerd of gedeactiveerd worden
        private void button1_Click(object sender, EventArgs e)
        {
            help = !help;
            Panel.Invalidate();
        }
        //veranderd de waarde van het array element gelinkt aan het vakje waarbinnen geklikt is (indien deze zet is toegestaand)
        private void veranderbeurt ()
        {
            if (beurt == 1)
            {

                beurt = 2;
                label1.Text = "blauw is aan zet";
            }

            else
            {
                beurt = 1;
                label1.Text = "rood is aan zet";
            }

            int z = aantalstenen_rood();
            int k = aantalstenen_blauw();
            label_rood.Text = z + " stenen";
            label_blauw.Text = k + " stenen";
        }
        private void zetwaardes(object sender, MouseEventArgs mea)
        {
            // bepaalt welke waarde van de array overeenkomt met het vakje waarop geklikt is
            for (int a = 0; a < hor; a++)
            {
                if ((a * breedte) < mea.X && mea.X < ((a + 1) * breedte))
                {
                    for (int b = 0; b < vert; b++)
                    {

                        if ((b * breedte) < mea.Y && mea.Y < ((b + 1) * breedte))
                            if (mogelijk(a, b))
                            {
                                // past de waarde aan naar de waarde van de speler die nu aan de beurt is
                                this.vak[a, b] = beurt;
                                slastenen(a, b);
                                standopslaan();
                                aantalzetten++; 
                                veranderbeurt();
                            }

                    }
                }

            }

            Panel.Invalidate();
        }
        // telt het aantal rode stenen (aka aantal int in de array met waarde 1)
        private int aantalstenen_rood()
        {
            int aantalrood = 0;
            for (int i = 0; i < hor; i++)
            {

                for (int j = 0; j < vert; j++)
                {
                    if (vak[i, j] == 1)
                        aantalrood++;
                }
            }
            return aantalrood;
        }
        // telt het aantal blauwe stenen (aka aantal int in de array met waarde 2)
        private int aantalstenen_blauw()
        {
            int aantalblauw = 0;
            for (int i = 0; i < hor; i++)
            {

                for (int j = 0; j < vert; j++)
                {
                    if (vak[i, j] == 2)
                        aantalblauw++;
                }
            }
            return aantalblauw;
        }
        // test of een huidige zet mogelijk is
        bool mogelijk(int x, int y)
        {
            if (vak[x, y] == 0) // is het vakje leeg?
            {
                // richting wordt bepaald waarin een steen van de andere kleur staat
                for (int dx = -1; dx < 2; dx++)
                {
                    for (int dy = -1; dy < 2; dy++)
                    {
                        if ((x + dx < hor && y + dy < vert) && (x + dx >= 0 && y + dy >= 0))
                        {
                            if (vak[x + dx, y + dy] != beurt && vak[x + dx, y + dy] != 0)
                            {
                                // kijkt of in deze richting ook daadwerkelijk stenen worden ingesloten
                                if (ingesloten(x, y, dx, dy))
                                {
                                    return true;
                                }
                            }
                        }
                    }
                }

            }
            return false;


        }
        // kijkt of in deze richting ook daadwerkelijk stenen worden ingesloten
        bool ingesloten(int x, int y, int dx, int dy)
        {

            for (int a = 1; a < 6; a++)
            {
                if ((x + a * dx < hor && y + a * dy < vert) && (x + a * dx >= 0 && y + a * dy >= 0))
                {
                    if (vak[x + a * dx, y + a * dy] == beurt)
                    {
                        // waardes vastzetten van de richting waarin en het aantal stenen dat wordt ingesloten
                        this.richtingx = dx;
                        this.richtingy = dy;
                        this.aantal = a;
                        return true;
                    }
                    if (vak[x + a * dx, y + a * dy] == 0)
                        return false;
                }
            }
            return false;
        }
        //alle ingesloten stenen krijgen de waarde van de speler die nu aan de beurt is
        private void slastenen(int x, int y)
        {
            for (int dx = -1; dx < 2; dx++)
            {
                for (int dy = -1; dy < 2; dy++)
                {

                    if ((x + dx < hor && y + dy < vert) && (x + dx >= 0 && y + dy >= 0))
                    {
                        if (vak[x + dx, y + dy] != beurt && vak[x + dx, y + dy] != 0)
                        {
                            int a = this.afstand(x, y, dx, dy);
                            {
                                for (int b = 1; b < a; b++)
                                {
                                    vak[x + b * dx, y + b * dy] = beurt;
                                }
                            }
                        }
                    }
                }
            }

        }
        // bepaald het aantal stenen dat wordt ingesloten
        int afstand(int x, int y, int dx, int dy)
        {
            for (int a = 1; a < 6; a++)
            {
                if ((x + a * dx < hor && y + a * dy < vert) && (x + a * dx >= 0 && y + a * dy >= 0))
                {
                    if (vak[x + a * dx, y + a * dy] == beurt)
                    {
                        return a;
                    }
                    if (vak[x + a * dx, y + a * dy] == 0)
                        return 0;
                }
            }
            return 0;
        }
        // hier wordt het speelveld getekend
        private void tekenveld(object sender, PaintEventArgs pea)
        {
            zet_niet_mogelijk = true;
            for (int x = 0; x < hor; x++)
            {
                for (int y = 0; y < vert; y++)
                {
                    // dit zijn de vakjes
                    pea.Graphics.DrawRectangle(Pens.Black, 0 + x * breedte, 0 + y * breedte, breedte, breedte);
                    // hier worden de hulp cirkels getekend als de hulpknop aanstaat
                    if (help == true)
                    {
                        if (mogelijk(x, y))
                        {
                            double a = (3 * breedte)/7;
                            pea.Graphics.DrawEllipse(Pens.Gray, (int) (a + x * breedte), (int) (a + y * breedte), breedte/7, breedte/7);
                        }
                    }
                    if (mogelijk(x, y))
                    {
                        zet_niet_mogelijk = false;
                        einde_spel = false;
                    }
                    // hier worden de stenen getekend op basis van de waardes in de array
                    if (this.vak[x, y] == 1)
                        pea.Graphics.FillEllipse(Brushes.Red, 0 + x * breedte, 0 + y * breedte, breedte, breedte);
                    if (this.vak[x, y] == 2)
                        pea.Graphics.FillEllipse(Brushes.Blue, 0 + x * breedte, 0 + y * breedte, breedte, breedte);

                }
            }
            // hier wordt het spel beeindigd en de winnaar bekend gemaakt als alle hokjes gevuld zijn
            if (bordvol())
            {
                int r = aantalstenen_rood();
                int b = aantalstenen_blauw();
                if (r > b)
                    MessageBox.Show("Einde spel, rood heeft gewonnen!");
                if (b > r)
                {
                    MessageBox.Show("Einde spel, blauw heeft gewonnen!");
                }
                if (r == b)
                    MessageBox.Show("Einde spel, het is gelijkspel");
                zet_niet_mogelijk = false;
                startspel();
                Panel.Invalidate();

            }
            // hier wordt het spel beeindigd en de winnaar bekend gemaakt als voor beide spelers geen zetten meer mogelijk zijn
            if (einde_spel == true)
            {
                int r = aantalstenen_rood();
                int b = aantalstenen_blauw();
                if (r > b)
                    MessageBox.Show("Geen zet meer mogelijk, rood heeft gewonnen!");
                if (b > r)
                {
                    MessageBox.Show("Geen zet meer mogelijk, blauw heeft gewonnen!");
                }
                if (r == b)
                    MessageBox.Show("Geen zet meer mogelijk, het is gelijkspel");
                zet_niet_mogelijk = false;
                startspel();
                Panel.Invalidate();

            }
            // hier wordt de beurt overgegeven aan de andere speler als voor de huidige speler geen zetten mogelijk zijn
            if (zet_niet_mogelijk == true)
            {
                einde_spel = true;
                MessageBox.Show("geen zet mogelijk, de ander is aan de beurt");
                if (beurt == 1)
                {
                    beurt = 2;
                    label1.Text = "blauw is aan zet";
                }

                else
                {
                    beurt = 1;
                    label1.Text = "rood is aan zet";
                }
                Panel.Invalidate();
            }
        }
        // controleerd of het bord vol ligt
        bool bordvol()
        {
            for (int i = 0; i < hor; i++)
                for (int j = 0; j < vert; j++)
                    if (vak[i, j] == 0)
                        return false;
            return true;
        }
        // tekent het kleine rode cirkeltje boven de telling van het aantal rode stenen
        private void panel_rood_Paint(object sender, PaintEventArgs pea)
        {
            Graphics gr = pea.Graphics;
            gr.FillEllipse(Brushes.Red, 0, 0, panel_rood.Width - 1, panel_rood.Height - 1);
        }
        // tekent het kleine blauwe cirkeltje boven de telling van het aantal blauwe stenen
        private void panel_blauw_Paint(object sender, PaintEventArgs pea)
        {
            Graphics gr = pea.Graphics;
            gr.FillEllipse(Brushes.Blue, 0, 0, panel_rood.Width - 1, panel_rood.Height - 1);
        }
        // herstard het spel wanneer het aantal hokjes is aangepast
        private void button2_Click(object sender, EventArgs e)
        {
            startspel();
            Panel.Invalidate();
        }

        //hier wordt op omslachtige wijze de array van de huidige stand in de list van arrays opgeslagen
       private void standopslaan ()
        {
            // dit moet via een nieuw int omdat anders alleen de verwijzing wordt opgeslagen en daar hebben we niets aan
            int[,] huidigvak;
            huidigvak = new int[hor, vert];
            for (int i = 0; i < hor; i++)
            {

                for (int j = 0; j < vert; j++)
                {
                    huidigvak[i, j] = vak[i, j];
                }
            }
           standoud.Add(huidigvak);
        } 
        
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        // deze eventhandler reageert op de knop terug
        private void Terug_Click(object sender, EventArgs e)
        {
            // als er meer dan één zet gedaan is wordt hier de huidige stand (vak) vervangen met de vorige stand (opgeslagen in aantalzetten)
            // (-2 omdat aantal zetten 1 voorloopt en ook de huidige stand al heeft opgeslagen)
            // vervolgens wordt de zet die gedaan was ook uit het geheugen van zetten gewist en wordt het aantal zetten terug gezet, ook wordt ervoor gezorgd dat de juiste persoon weer aan de beurt is
            if (aantalzetten >= 2)
            {
                vak = (int[,])standoud[aantalzetten - 2];
                standoud.RemoveAt(aantalzetten - 1);
                aantalzetten--;
                veranderbeurt();
            }
            // als maar 1 zet is gedaan of nog helemaal geen wordt de beginstand weer opgestart
            else
            {
                startspel();
            }
            Panel.Invalidate();

        } 
    }
}