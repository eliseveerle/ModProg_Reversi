﻿
namespace Reversi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Panel = new System.Windows.Forms.FlowLayoutPanel();
            this.Reset = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel_rood = new System.Windows.Forms.Panel();
            this.panel_blauw = new System.Windows.Forms.Panel();
            this.label_rood = new System.Windows.Forms.Label();
            this.label_blauw = new System.Windows.Forms.Label();
            this.label_x = new System.Windows.Forms.Label();
            this.label_y = new System.Windows.Forms.Label();
            this.textBox_x = new System.Windows.Forms.TextBox();
            this.textBox_y = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.Terug = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Panel
            // 
            this.Panel.Location = new System.Drawing.Point(10, 90);
            this.Panel.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Panel.Name = "Panel";
            this.Panel.Size = new System.Drawing.Size(419, 419);
            this.Panel.TabIndex = 0;
            // 
            // Reset
            // 
            this.Reset.Location = new System.Drawing.Point(11, 9);
            this.Reset.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Reset.Name = "Reset";
            this.Reset.Size = new System.Drawing.Size(92, 19);
            this.Reset.TabIndex = 1;
            this.Reset.Text = "Nieuw Spel";
            this.Reset.UseVisualStyleBackColor = true;
            this.Reset.Click += new System.EventHandler(this.Reset_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(11, 34);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 19);
            this.button1.TabIndex = 2;
            this.button1.Text = "Help";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(246, 68);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Rood begint";
            // 
            // panel_rood
            // 
            this.panel_rood.Location = new System.Drawing.Point(249, 11);
            this.panel_rood.Margin = new System.Windows.Forms.Padding(2);
            this.panel_rood.Name = "panel_rood";
            this.panel_rood.Size = new System.Drawing.Size(43, 42);
            this.panel_rood.TabIndex = 3;
            this.panel_rood.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_rood_Paint);
            // 
            // panel_blauw
            // 
            this.panel_blauw.Location = new System.Drawing.Point(308, 11);
            this.panel_blauw.Margin = new System.Windows.Forms.Padding(2);
            this.panel_blauw.Name = "panel_blauw";
            this.panel_blauw.Size = new System.Drawing.Size(43, 42);
            this.panel_blauw.TabIndex = 4;
            this.panel_blauw.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_blauw_Paint);
            // 
            // label_rood
            // 
            this.label_rood.AutoSize = true;
            this.label_rood.Location = new System.Drawing.Point(246, 55);
            this.label_rood.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_rood.Name = "label_rood";
            this.label_rood.Size = new System.Drawing.Size(35, 13);
            this.label_rood.TabIndex = 5;
            this.label_rood.Text = "label2";
            // 
            // label_blauw
            // 
            this.label_blauw.AutoSize = true;
            this.label_blauw.Location = new System.Drawing.Point(305, 55);
            this.label_blauw.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_blauw.Name = "label_blauw";
            this.label_blauw.Size = new System.Drawing.Size(35, 13);
            this.label_blauw.TabIndex = 6;
            this.label_blauw.Text = "label3";
            // 
            // label_x
            // 
            this.label_x.AutoSize = true;
            this.label_x.Location = new System.Drawing.Point(117, 15);
            this.label_x.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_x.Name = "label_x";
            this.label_x.Size = new System.Drawing.Size(62, 13);
            this.label_x.TabIndex = 7;
            this.label_x.Text = "blokjes x-as";
            // 
            // label_y
            // 
            this.label_y.AutoSize = true;
            this.label_y.Location = new System.Drawing.Point(117, 40);
            this.label_y.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_y.Name = "label_y";
            this.label_y.Size = new System.Drawing.Size(62, 13);
            this.label_y.TabIndex = 8;
            this.label_y.Text = "blokjes y-as";
            // 
            // textBox_x
            // 
            this.textBox_x.Location = new System.Drawing.Point(187, 13);
            this.textBox_x.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_x.Name = "textBox_x";
            this.textBox_x.Size = new System.Drawing.Size(46, 20);
            this.textBox_x.TabIndex = 9;
            this.textBox_x.Text = "6";
            // 
            // textBox_y
            // 
            this.textBox_y.Location = new System.Drawing.Point(187, 37);
            this.textBox_y.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_y.Name = "textBox_y";
            this.textBox_y.Size = new System.Drawing.Size(46, 20);
            this.textBox_y.TabIndex = 10;
            this.textBox_y.Text = "6";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(117, 59);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(116, 22);
            this.button2.TabIndex = 11;
            this.button2.Text = "OK";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Terug
            // 
            this.Terug.Location = new System.Drawing.Point(10, 59);
            this.Terug.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Terug.Name = "Terug";
            this.Terug.Size = new System.Drawing.Size(92, 22);
            this.Terug.TabIndex = 12;
            this.Terug.Text = "Terug";
            this.Terug.UseVisualStyleBackColor = true;
            this.Terug.Click += new System.EventHandler(this.Terug_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(438, 518);
            this.Controls.Add(this.label_blauw);
            this.Controls.Add(this.Terug);
            this.Controls.Add(this.label_rood);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.panel_blauw);
            this.Controls.Add(this.panel_rood);
            this.Controls.Add(this.textBox_y);
            this.Controls.Add(this.textBox_x);
            this.Controls.Add(this.label_y);
            this.Controls.Add(this.label_x);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Reset);
            this.Controls.Add(this.Panel);
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel Panel;
        private System.Windows.Forms.Button Reset;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel_rood;
        private System.Windows.Forms.Panel panel_blauw;
        private System.Windows.Forms.Label label_rood;
        private System.Windows.Forms.Label label_blauw;
        private System.Windows.Forms.Label label_x;
        private System.Windows.Forms.Label label_y;
        private System.Windows.Forms.TextBox textBox_x;
        private System.Windows.Forms.TextBox textBox_y;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button Terug;
    }
}